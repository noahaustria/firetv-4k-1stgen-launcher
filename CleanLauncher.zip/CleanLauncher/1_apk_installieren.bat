@echo off
set IP=192.168.20.153
echo Verbinde mit %IP% ...
adb connect %IP%:5555
echo.
echo Installiere Clean Launcher ...
adb -s %IP%:5555 install -r app\build\outputs\apk\debug\app-debug.apk
echo.
echo Fertig. Starte jetzt am Fernseher unter "Apps" den "Clean Launcher" und teste ihn.
pause
