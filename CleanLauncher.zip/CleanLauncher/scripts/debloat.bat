@echo off
REM Entfernt alle Pakete aus packages.txt fuer den Nutzer 0 (rueckgaengig mit restore_packages.bat)
set IP=192.168.20.153
adb connect %IP%:5555
adb -s %IP%:5555 shell pm list packages > paketliste_backup.txt
for /f "eol=# tokens=*" %%p in (packages.txt) do adb -s %IP%:5555 shell pm uninstall -k --user 0 %%p
pause
