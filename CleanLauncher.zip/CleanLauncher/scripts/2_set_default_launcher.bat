@echo off
REM ERST ausfuehren, wenn der Clean Launcher installiert ist!
set IP=192.168.20.153
adb connect %IP%:5555
adb -s %IP%:5555 shell pm disable-user --user 0 com.amazon.tv.launcher
adb -s %IP%:5555 shell input keyevent KEYCODE_HOME
pause
