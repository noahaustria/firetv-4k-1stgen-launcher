@echo off
set IP=192.168.20.153
adb connect %IP%:5555
adb -s %IP%:5555 shell pm enable com.amazon.tv.launcher
adb -s %IP%:5555 shell cmd package install-existing com.amazon.tv.launcher
pause
