@echo off
set IP=192.168.20.153
adb connect %IP%:5555
for /f "eol=# tokens=*" %%p in (packages.txt) do adb -s %IP%:5555 shell cmd package install-existing %%p
pause
