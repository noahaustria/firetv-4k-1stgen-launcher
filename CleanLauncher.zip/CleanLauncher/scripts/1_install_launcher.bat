@echo off
set IP=192.168.20.153
adb connect %IP%:5555
adb -s %IP%:5555 install -r ..\app\build\outputs\apk\debug\app-debug.apk
pause
