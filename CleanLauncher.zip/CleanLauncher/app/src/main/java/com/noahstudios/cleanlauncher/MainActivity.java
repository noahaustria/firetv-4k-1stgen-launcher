package com.noahstudios.cleanlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String PREFS = "launcher";
    private static final String KEY_HIDDEN = "hidden";

    private static class AppEntry {
        String label;
        String pkg;
        Intent launch;
        Drawable icon;
    }

    private final List<AppEntry> apps = new ArrayList<>();
    private BaseAdapter adapter;
    private GridView grid;
    private SharedPreferences prefs;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            loadApps();
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0F1A);
        root.setPadding(dp(48), dp(28), dp(48), dp(16));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Apps");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(0xFFB8C0D4);
        clock.setTextSize(24);
        header.addView(clock, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        grid = new GridView(this);
        grid.setNumColumns(6);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalSpacing(dp(12));
        grid.setHorizontalSpacing(dp(12));
        grid.setSelector(new ColorDrawable(0x44FFFFFF));
        grid.setDrawSelectorOnTop(false);
        grid.setClipToPadding(false);
        grid.setPadding(0, dp(24), 0, dp(24));

        adapter = new BaseAdapter() {
            @Override public int getCount() { return apps.size(); }
            @Override public Object getItem(int i) { return apps.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                LinearLayout cell;
                ImageView img;
                TextView label;
                if (convertView == null) {
                    cell = new LinearLayout(MainActivity.this);
                    cell.setOrientation(LinearLayout.VERTICAL);
                    cell.setGravity(Gravity.CENTER);
                    cell.setPadding(dp(8), dp(12), dp(8), dp(12));
                    img = new ImageView(MainActivity.this);
                    img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    cell.addView(img, new LinearLayout.LayoutParams(dp(88), dp(88)));
                    label = new TextView(MainActivity.this);
                    label.setTextColor(Color.WHITE);
                    label.setTextSize(15);
                    label.setGravity(Gravity.CENTER);
                    label.setSingleLine(true);
                    label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.topMargin = dp(8);
                    cell.addView(label, lp);
                    cell.setLayoutParams(new GridView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, dp(150)));
                } else {
                    cell = (LinearLayout) convertView;
                }
                img = (ImageView) cell.getChildAt(0);
                label = (TextView) cell.getChildAt(1);
                AppEntry e = apps.get(position);
                img.setImageDrawable(e.icon);
                label.setText(e.label);
                return cell;
            }
        };
        grid.setAdapter(adapter);

        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                try {
                    startActivity(apps.get(position).launch);
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "App konnte nicht gestartet werden", Toast.LENGTH_SHORT).show();
                }
            }
        });

        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showAppMenu(apps.get(position));
                return true;
            }
        });

        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        grid.requestFocus();
    }

    private void showAppMenu(final AppEntry e) {
        new AlertDialog.Builder(this)
                .setTitle(e.label)
                .setItems(new String[]{"Ausblenden", "App-Info", "Abbrechen"},
                        new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int which) {
                                if (which == 0) {
                                    Set<String> hidden = new HashSet<>(
                                            prefs.getStringSet(KEY_HIDDEN, new HashSet<String>()));
                                    hidden.add(e.pkg);
                                    prefs.edit().putStringSet(KEY_HIDDEN, hidden).apply();
                                    loadApps();
                                } else if (which == 1) {
                                    try {
                                        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.parse("package:" + e.pkg));
                                        startActivity(i);
                                    } catch (Exception ex) {
                                        Toast.makeText(MainActivity.this, "Nicht verfügbar", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        })
                .show();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Set<String> hidden = prefs.getStringSet(KEY_HIDDEN, new HashSet<String>());
        Map<String, AppEntry> map = new LinkedHashMap<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String p = ri.activityInfo.packageName;
                if (p.equals(getPackageName()) || map.containsKey(p) || hidden.contains(p)) continue;
                AppEntry e = new AppEntry();
                e.pkg = p;
                e.label = String.valueOf(ri.loadLabel(pm));
                e.icon = ri.loadIcon(pm);
                Intent l = new Intent(Intent.ACTION_MAIN);
                l.addCategory(cat);
                l.setClassName(p, ri.activityInfo.name);
                l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                e.launch = l;
                map.put(p, e);
            }
        }
        apps.clear();
        apps.addAll(map.values());
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        if (!receiverRegistered) {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_PACKAGE_ADDED);
            f.addAction(Intent.ACTION_PACKAGE_REMOVED);
            f.addAction(Intent.ACTION_PACKAGE_CHANGED);
            f.addDataScheme("package");
            registerReceiver(pkgReceiver, f);
            receiverRegistered = true;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (receiverRegistered) {
            unregisterReceiver(pkgReceiver);
            receiverRegistered = false;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (grid != null) {
            grid.setSelection(0);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            prefs.edit().remove(KEY_HIDDEN).apply();
            loadApps();
            Toast.makeText(this, "Ausgeblendete Apps wieder sichtbar", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        // Als Launcher nichts tun
    }
}
