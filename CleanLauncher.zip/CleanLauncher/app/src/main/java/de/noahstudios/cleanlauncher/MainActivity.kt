package de.noahstudios.cleanlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

data class AppEntry(
    val label: String,
    val pkg: String?,
    val icon: Drawable,
    val intent: Intent,
    val hidden: Boolean
)

class MainActivity : Activity() {

    private lateinit var grid: GridView
    private lateinit var hint: TextView
    private val entries = mutableListOf<AppEntry>()
    private val adapter = AppAdapter()
    private var showHidden = false

    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F1419"))
            setPadding(dp(48), dp(28), dp(48), dp(16))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Clean Launcher"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 26f
            setTextColor(Color.parseColor("#B0BEC5"))
        }
        header.addView(clock)
        root.addView(
            header,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val ring = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(12).toFloat()
            setStroke(dp(4), Color.WHITE)
            setColor(Color.TRANSPARENT)
        }

        grid = GridView(this)
        grid.setNumColumns(5)
        grid.setHorizontalSpacing(dp(16))
        grid.setVerticalSpacing(dp(16))
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH)
        grid.setPadding(dp(8), dp(24), dp(8), dp(8))
        grid.setClipToPadding(false)
        grid.setSelector(ring)
        grid.setDrawSelectorOnTop(true)
        grid.setVerticalScrollBarEnabled(false)
        grid.setFocusable(true)
        grid.setAdapter(adapter)
        grid.setOnItemClickListener { _, _, pos, _ -> launch(entries[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            showOptions(entries[pos])
            true
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        hint = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#78909C"))
        }
        root.addView(
            hint,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        setContentView(root)
        updateHint()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        grid.requestFocus()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) {
            grid.setSelection(0)
        }
    }

    // Im Launcher soll Zurueck nichts tun
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showHidden = !showHidden
            updateHint()
            loadApps()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun updateHint() {
        hint.text = if (showHidden) {
            "Ausgeblendete Apps werden angezeigt (blass)  |  Menue-Taste: wieder verbergen  |  OK lange druecken: Optionen"
        } else {
            "OK lange druecken: Optionen  |  Menue-Taste: ausgeblendete Apps anzeigen"
        }
    }

    private fun hiddenSet(): MutableSet<String> =
        HashSet(prefs.getStringSet("hidden", emptySet()) ?: emptySet())

    private fun loadApps() {
        val pm = packageManager
        val hidden = hiddenSet()
        val seen = HashSet<String>()
        val list = ArrayList<AppEntry>()

        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = ri.loadLabel(pm).toString()
                val icon: Drawable = ri.activityInfo.loadBanner(pm) ?: ri.loadIcon(pm)
                val intent = Intent(Intent.ACTION_MAIN)
                    .addCategory(cat)
                    .setClassName(pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                list.add(AppEntry(label, pkg, icon, intent, hidden.contains(pkg)))
            }
        }

        list.sortBy { it.label.lowercase() }
        entries.clear()
        entries.addAll(list.filter { showHidden || !it.hidden })

        val settingsIcon = getDrawable(android.R.drawable.ic_menu_preferences)!!
        entries.add(AppEntry("Einstellungen", null, settingsIcon, Intent(Settings.ACTION_SETTINGS), false))

        adapter.notifyDataSetChanged()
    }

    private fun launch(e: AppEntry) {
        try {
            startActivity(e.intent)
        } catch (ex: Exception) {
            Toast.makeText(this, "Konnte nicht gestartet werden", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showOptions(e: AppEntry) {
        val pkg = e.pkg ?: return
        val options = arrayOf(
            if (e.hidden) "Einblenden" else "Ausblenden",
            "App-Info",
            "Deinstallieren"
        )
        AlertDialog.Builder(this)
            .setTitle(e.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val set = hiddenSet()
                        if (e.hidden) set.remove(pkg) else set.add(pkg)
                        prefs.edit().putStringSet("hidden", set).apply()
                        loadApps()
                    }
                    1 -> tryStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
                    2 -> tryStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
                }
            }
            .show()
    }

    private fun tryStart(i: Intent) {
        try {
            startActivity(i)
        } catch (ex: Exception) {
            Toast.makeText(this, "Auf diesem Geraet nicht moeglich", Toast.LENGTH_SHORT).show()
        }
    }

    inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = entries.size
        override fun getItem(position: Int): Any = entries[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val e = entries[position]
            val tile = (convertView as? LinearLayout) ?: buildTile()
            val img = tile.getChildAt(0) as ImageView
            val tv = tile.getChildAt(1) as TextView
            img.setImageDrawable(e.icon)
            tv.text = e.label
            tile.alpha = if (e.hidden) 0.4f else 1f
            return tile
        }

        private fun buildTile(): LinearLayout {
            val tile = LinearLayout(this@MainActivity)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER_HORIZONTAL
            tile.setPadding(dp(8), dp(8), dp(8), dp(6))
            tile.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#1B232C"))
            }
            tile.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(128))

            val img = ImageView(this@MainActivity)
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            tile.addView(img, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(84)))

            val tv = TextView(this@MainActivity)
            tv.textSize = 15f
            tv.setTextColor(Color.WHITE)
            tv.maxLines = 1
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            tile.addView(tv, lp)
            return tile
        }
    }
}
