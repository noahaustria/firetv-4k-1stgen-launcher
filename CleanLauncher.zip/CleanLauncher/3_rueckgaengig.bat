@echo off
set IP=192.168.20.153
adb connect %IP%:5555
echo Aktiviere den Amazon-Launcher wieder ...
adb -s %IP%:5555 shell pm enable com.amazon.tv.launcher
echo Fertig. Die Home-Taste fuehrt wieder zum Original-Startbildschirm.
pause
