@echo off
set IP=192.168.20.153
adb connect %IP%:5555
echo.
echo Deaktiviere den Amazon-Launcher (mit Werbung) ...
adb -s %IP%:5555 shell pm disable-user --user 0 com.amazon.tv.launcher
echo.
echo Starte Clean Launcher ...
adb -s %IP%:5555 shell am start -a android.intent.action.MAIN -c android.intent.category.HOME
echo.
echo Wenn alles klappt, fuehrt die Home-Taste jetzt zum Clean Launcher.
echo Falls etwas nicht klappt: 3_rueckgaengig.bat ausfuehren.
pause
